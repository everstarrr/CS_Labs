namespace Lab2.Model;

// Модель данных для слова
public class WordModel
{
    public string? Word { get; set; }
    public string? Construction { get; set; }
    public string? Root { get; set; }
}